-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 12, 2021 at 07:40 PM
-- Server version: 10.1.40-MariaDB-1~trusty
-- PHP Version: 7.0.13-1+deb.sury.org~trusty+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bcm`
--

-- --------------------------------------------------------

--
-- Table structure for table `BCM_INVOICE`
--

DROP TABLE IF EXISTS `BCM_INVOICE`;
CREATE TABLE `BCM_INVOICE` (
  `INVOICE_REFERENCE` varchar(25) NOT NULL,
  `SUPPLIER_REF` int(11) NOT NULL,
  `INVOICE_DATE` varchar(255) NOT NULL,
  `INVOICE_STATUS` varchar(25) DEFAULT NULL,
  `INVOICE_HOLD_REASON` varchar(255) DEFAULT NULL,
  `INVOICE_DESCRIPTION` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BCM_INVOICE`
--

INSERT INTO `BCM_INVOICE` (`INVOICE_REFERENCE`, `SUPPLIER_REF`, `INVOICE_DATE`, `INVOICE_STATUS`, `INVOICE_HOLD_REASON`, `INVOICE_DESCRIPTION`) VALUES
('INV_PO001', 8, '28 FEB 2017', 'Paid', NULL, 'Part payment for vehicle '),
('INV_PO001.1', 8, '04 APR 2017', 'Paid', NULL, 'Final payment for vehicle'),
('INV_PO002.1', 7, '01 MAR 2017', 'Paid', NULL, 'Part payment for purchase'),
('INV_PO002.2', 7, '02 MAY 2017', 'Paid', NULL, 'Part payment for purchase'),
('INV_PO002.3', 7, '05 AUG 2017', 'Pending', NULL, 'Final payment for purchas'),
('INV_PO003.1', 1, '22 MAR 2017', 'Paid', NULL, 'Purchase of screens.'),
('INV_PO003.2', 1, '15 MAY 2017', 'Paid', NULL, 'Final payment for purchas'),
('INV_PO004', 6, '15 FEB 2017', 'Paid', NULL, 'Payment for pen'),
('INV_PO004.1', 6, '20 MAR 2017', 'Paid', NULL, 'Paper reams.'),
('INV_PO005.1', 2, '18 MAY 2017', 'Pending', 'Damaged magazine', NULL),
('INV_PO005.2', 2, '22 JUN 2017', 'Paid', NULL, NULL),
('INV_PO006.1', 10, '22 MAR 2017', 'Paid', NULL, 'First delivery'),
('INV_PO006.2', 10, '18 04 2017', 'Paid', NULL, 'Second delivery'),
('INV_PO006.3', 10, '21 MAY 2017', 'Paid', NULL, 'Third delivery'),
('INV_PO006.4', 10, '17 06 2017', 'Paid', NULL, 'Fourth delivery'),
('INV_PO006.5', 10, '27 JUL 2017', 'Paid', NULL, 'Fifth delivery'),
('INV_PO006.6', 10, '16 08 2017', 'Paid', NULL, 'Sixth delivery'),
('INV_PO007.1', 9, '30 JUL 2017', 'Paid', NULL, 'Trip for Saunders'),
('INV_PO008.1', 5, '02 AUG 2017', 'Paid', NULL, 'Computer oders invoice - '),
('INV_PO008.2', 5, '28 08 2017', 'Paid', NULL, 'Computer oders invoice - '),
('INV_PO009.1', 3, '24 AUG 2017', 'Paid', NULL, 'Security vests'),
('INV_PO010.1', 4, '15 AUG 2017', 'Paid', NULL, 'Electronic spare parts - '),
('INV_PO011.1', 6, '18 SEP 2017', 'Paid', NULL, 'Stationeries'),
('INV_PO012.1', 8, '07 AUG 2017', 'Paid', NULL, 'Vehicle spare parts - Par'),
('INV_PO012.2', 8, '04 09 2017', 'Paid', NULL, 'Vehicle spare parts - Par'),
('INV_PO012.3', 8, '29 SEP 2017', 'Paid', NULL, 'Vehicle spare parts - Par'),
('INV_PO013.1', 7, '28 SEP 2017', 'Paid', NULL, 'Car purchase'),
('INV_PO014.1', 1, '03 OCT 2017', 'Paid', NULL, 'Invoice payment SN#001'),
('INV_PO014.2', 1, '15 OCT 2017', 'Paid', NULL, 'Invoice payment SN#002'),
('INV_PO014.3', 1, '27 10 2017', 'Paid', NULL, 'Invoice payment SN#003'),
('INV_PO014.4', 1, '05 NOV 2017', 'Pending', '1 faulty HD to return before payment', 'Invoice payment SN#004');

-- --------------------------------------------------------

--
-- Table structure for table `BCM_ORDER`
--

DROP TABLE IF EXISTS `BCM_ORDER`;
CREATE TABLE `BCM_ORDER` (
  `ORDER_REF` varchar(25) NOT NULL,
  `SUPPLIER_REF` int(11) NOT NULL,
  `ORDER_DATE` varchar(255) NOT NULL,
  `ORDER_DESCRIPTION` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BCM_ORDER`
--

INSERT INTO `BCM_ORDER` (`ORDER_REF`, `SUPPLIER_REF`, `ORDER_DATE`, `ORDER_DESCRIPTION`, `ORDER_STATUS`) VALUES
('PO001', 8, '03 JAN 2017', 'Vehicle Spare parts', 'Closed'),
('PO002', 7, '10 JAN 2017', 'Purchase of Car', 'Open'),
('PO003', 1, '24 JAN 2017', 'Computer screens', 'Closed'),
('PO004', 6, '07 FEB 2017', 'Purchase of Stationeries', 'Closed'),
('PO005', 2, '07 APR 2017', 'International Magazines', 'Closed'),
('PO006', 10, '16 FEB 2017', 'Stationery orders', 'Open'),
('PO007', 9, '03 06 2017', 'Taxi services fees', 'Closed'),
('PO008', 5, '05 JUN 2017', 'Orders of computer spare parts', 'Open'),
('PO009', 3, '18 JUN 2017', 'Security vests', 'Open'),
('PO010', 4, '03 JUL 2017', 'Electronic spare parts', 'Closed'),
('PO011', 6, '06 07 2017', 'Purchase of Stationeries', 'Closed'),
('PO012', 8, '16 AUG 2017', 'Vehicle Spare parts', 'Open'),
('PO013', 7, '20 AUG 2017', 'Purchase of Cars', 'Closed'),
('PO014', 1, '15 SEP 2017', 'Purchases of Digital equipment', 'Open');

-- --------------------------------------------------------

--
-- Table structure for table `BCM_ORDER_LINE`
--

DROP TABLE IF EXISTS `BCM_ORDER_LINE`;
CREATE TABLE `BCM_ORDER_LINE` (
  `ORDER_LINE_ID` int(11) NOT NULL,
  `ORDER_LINE_REF` varchar(25) NOT NULL,
  `ORDER_REF` varchar(25) NOT NULL,
  `INVOICE_REFERENCE` varchar(25) NOT NULL,
  `ORDER_STATUS` varchar(25) DEFAULT NULL,
  `ORDER_LINE_DESCRIPTION` varchar(255) DEFAULT NULL,
  `ORDER_LINE_AMOUNT` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BCM_ORDER_LINE`
--

INSERT INTO `BCM_ORDER_LINE` (`ORDER_LINE_ID`, `ORDER_LINE_REF`, `ORDER_REF`, `INVOICE_REFERENCE`, `ORDER_STATUS`, `ORDER_LINE_DESCRIPTION`, `ORDER_LINE_AMOUNT`) VALUES
(1, 'PO001-1', 'PO001', 'INV_PO001', 'Received', 'Back lights', 2500),
(2, 'PO001-2', 'PO001', 'INV_PO001', 'Received', 'Spark plug', 600),
(3, 'PO002-1', 'PO002', 'INV_PO002.1', 'Received', 'Purchase of Car Model X', 100000),
(4, 'PO003-1', 'PO003', 'INV_PO003.1', 'Received', 'Screens 22"', 22000),
(5, 'PO003-2', 'PO003', 'INV_PO003.1', 'Received', 'Screens 35"', 20300),
(6, 'PO003-3', 'PO003', 'INV_PO003.1', 'Received', 'Screens 15"', 5000),
(7, 'PO001-3', 'PO001', 'INV_PO001', 'Received', 'Fuel filter', 2000),
(8, 'PO004-1', 'PO004', 'INV_PO004', 'Received', 'Pen Parker blue', 2000),
(9, 'PO004-2', 'PO004', 'INV_PO004', 'Received', 'Pencil HB boxes', 1200),
(10, 'PO001-4', 'PO001', 'INV_PO001', 'Received', 'Air filter', 800),
(11, 'PO002-1', 'PO002', 'INV_PO002.2', 'Received', 'Purchase of Car Model X', 300000),
(12, 'PO005-1', 'PO005', 'INV_PO005.1', 'Received', 'National geo nature', 3000),
(13, 'PO005-2', 'PO005', 'INV_PO005.1', 'Received', 'Science world', 5000),
(14, 'PO003-4', 'PO003', 'INV_PO003.2', 'Received', 'Screens 35"', 10000),
(15, 'PO002-1', 'PO002', 'INV_PO002.3', 'Received', 'Purchase of Car Model X', 249000),
(16, 'PO004-3', 'PO004', 'INV_PO004.1', 'Received', 'Paper reams', 3000),
(17, 'PO004-4', 'PO004', '', 'Cancelled', 'Clips boxes', 600),
(18, 'PO005-3', 'PO005', 'INV_PO005.2', 'Received', 'Science world', 8000),
(19, 'PO005-4', 'PO005', 'INV_PO005.2', 'Received', 'Discovery mag', 5000),
(20, 'PO001-5', 'PO001', 'INV_PO001.1', 'Received', 'Brake disc', 3000),
(21, 'PO001-6', 'PO001', 'INV_PO001.1', 'Received', 'Axle', 1100),
(22, 'PO006-1', 'PO006', 'INV_PO006.1', 'Received', 'Packet 1', 24300),
(23, 'PO008-1', 'PO008', 'INV_PO008.1', 'Received', '10 HDDs 3TB', 30250),
(24, 'PO008-2', 'PO008', 'INV_PO008.1', 'Received', '10 Motherboard Asus PRIME Z270-A', 48000),
(25, 'PO009-1', 'PO009', 'INV_PO009.1', 'Received', 'Security vests for firewardens', 22500),
(26, 'PO010-1', 'PO010', 'INV_PO010.1', 'Received', 'Electronic Component Lead 2000 Kgs', 98000),
(27, 'PO010-1', 'PO010', 'INV_PO010.1', 'Received', 'Air Conditioner Fan Capacitor x 1000', 17500),
(28, 'PO010-2', 'PO010', 'INV_PO010.1', 'Received', 'Aluminium LED PCB Assemblies x 100', 28000),
(29, 'PO010-2', 'PO010', 'INV_PO010.1', 'Received', 'Starter capacitor x 2000', 18200),
(30, 'PO010-3', 'PO010', 'INV_PO010.1', 'Received', 'Block connector universal x 200', 21000),
(31, 'PO011-1', 'PO011', 'INV_PO011.1', 'Received', 'Staplers Heavy duty x 10', 3200),
(32, 'PO008-1', 'PO008', 'INV_PO008.2', 'Received', '10 HDDs 3TB', 30250),
(33, 'PO008-2', 'PO008', 'INV_PO008.2', 'Received', '10 Motherboard Asus PRIME Z270-A', 48000),
(34, 'PO006-1', 'PO006', 'INV_PO006.3', 'Received', 'Packet 3', 25400),
(35, 'PO011-2', 'PO011', 'INV_PO011.1', 'Received', 'Organizers x 200', 40000),
(36, 'PO012-1', 'PO012', 'INV_PO012.1', 'Received', 'Aluminium evaporator x 15', 3450),
(37, 'PO006-1', 'PO006', 'INV_PO006.4', 'Received', 'Packet 4', 50200),
(38, 'PO008-2', 'PO008', 'INV_PO008.2', 'Received', 'Seagate Barracuda 2TB SATA Hard Drive', 6950),
(39, 'PO012-1', 'PO012', 'INV_PO012.2', 'Received', 'Wheels and balancing', 40000),
(40, 'PO012-2', 'PO012', 'INV_PO012.1', 'Received', 'Servicing of cars', 37800),
(41, 'PO012-2', 'PO012', 'INV_PO012.2', 'Received', 'Dashboard for cards', 12500),
(42, 'PO012-2', 'PO012', 'INV_PO012.3', 'Received', 'Rear door + repair', 28000),
(43, 'PO012-3', 'PO012', 'INV_PO012.1', 'Received', 'High pressure fuel injector nozzle OEM x 10', 7250),
(44, 'PO012-4', 'PO012', 'INV_PO012.2', 'Received', 'Air suspension compressor x 3', 55870),
(45, 'PO012-5', 'PO012', 'INV_PO012.3', 'Received', 'Aluminium alloy set x 5', 43750),
(46, 'PO012-5', 'PO012', 'INV_PO012.3', 'Received', 'Master brake x 12', 12600),
(47, 'PO006-1', 'PO006', 'INV_PO006.5', 'Received', 'Packet 5', 70800),
(48, 'PO013-1', 'PO013', 'INV_PO013.1', 'Received', 'Audi Q5', 1452500),
(49, 'PO013-2', 'PO013', 'INV_PO013.1', 'Received', 'Audi Q7', 1974000),
(50, 'PO013-3', 'PO013', 'INV_PO013.1', 'Received', 'Chevrolet Equinox', 1302000),
(51, 'PO013-4', 'PO013', 'INV_PO013.1', 'Received', 'Hyundai Tucson', 1091125),
(52, 'PO006-1', 'PO006', 'INV_PO006.6', 'Received', 'Packet 6', 60000),
(53, 'PO007-1', 'PO007', 'INV_PO007.1', 'Received', 'Employee journey taxi service', 4500),
(54, 'PO007-2', 'PO007', 'INV_PO007.1', 'Received', 'Employee journey taxi service', 4200),
(55, 'PO007-3', 'PO007', '', 'Cancelled', 'Employee journey taxi service', 5200),
(56, 'PO007-4', 'PO007', 'INV_PO007.1', 'Received', 'Employee journey taxi service', 4800),
(57, 'PO007-5', 'PO007', 'INV_PO007.1', 'Received', 'Employee journey taxi service', 3700),
(58, 'PO006-1', 'PO006', 'INV_PO006.2', 'Received', 'Packet 2', 4300),
(59, 'PO014-1', 'PO014', 'INV_PO014.1', 'Received', '2.5 EXTERNAL TOSHIBA 1TB HARD DISK USB 3.0 x 2', 5600),
(60, 'PO014-2', 'PO014', 'INV_PO014.2', 'Received', '2.5 EXTERNAL TOSHIBA 2TB HARD DISK USB 3.0 x 3', 13250),
(61, 'PO014-3', 'PO014', 'INV_PO014.2', 'Received', 'NOTEBOOK SATA HDD - 500 GB x 5', 10000),
(62, 'PO014-4', 'PO014', 'INV_PO014.3', 'Received', '3TB SATA HARD DISK x 4', 15900),
(63, 'PO014-5', 'PO014', 'INV_PO014.4', 'Received', 'WESTERN DIGITAL USB 3.0 EXTERNAL HARD DISK 3.5 4TB x 2', 13850),
(64, 'PO014-1', 'PO014', '', 'Cancelled', 'FAN UNIT x 20', 800),
(65, 'PO014-1', 'PO014', 'INV_PO014.3', 'Received', 'EPSON EB-S31 3LCD PROJECTOR x 3', 54850),
(66, 'PO014-2', 'PO014', 'INV_PO014.1', 'Received', 'VIEWSONIC PJD5155 PROJECTOR', 17300),
(67, 'PO014-2', 'PO014', 'INV_PO014.1', 'Received', 'COOLER MASTER SEIDON120V V3 PLUS WATER-COOLING KIT x 5', 13500),
(68, 'PO014-3', 'PO014', 'INV_PO014.1', 'Received', 'GENIUS MEDIA POINTER 900BT x 3', 4275),
(69, 'PO014-3', 'PO014', 'INV_PO014.3', 'Received', 'USB WIRELESS <<T>> LASER POINTER PRESENTER x 2', 900),
(70, 'PO014-3', 'PO014', 'INV_PO014.4', 'Received', 'ASUS H110M-A (INTEL H110) DDR4 LGA1151 MATX x 4', 17600),
(71, 'PO014-3', 'PO014', 'INV_PO014.4', 'Received', 'ASUS B150M-K DDR4 (INTEL B150) LGA1151 MATX x 2', 11900),
(72, 'PO014-4', 'PO014', 'INV_PO014.1', 'Received', 'ASUS H81M-A (INTEL H81) LGA1150 MATX x 2', 7920),
(73, 'PO014-4', 'PO014', 'INV_PO014.2', 'Received', 'HP ADVANTAGE 4535 ALL-IN-ONE INKJET PRINTER', 3550),
(74, 'PO014-4', 'PO014', 'INV_PO014.1', 'Received', 'HP M277DW WIFI COLOUR LASERJET PRO MFP', 15200),
(75, 'PO014-5', 'PO014', 'INV_PO014.3', 'Received', 'HP OFFICEJET PRO 6830 E-ALL-IN-ONE PRINTER', 5300),
(76, 'PO014-5', 'PO014', 'INV_PO014.3', 'Received', 'EPSON LQ310 DOT MATRIX PRINTER', 12125),
(77, 'PO014-5', 'PO014', 'INV_PO014.1', 'Received', 'LENOVO B50-30 x 5', 72500),
(78, 'PO014-5', 'PO014', '', 'Cancelled', 'DELL N3543 CORE i5 x 3', 103800);

-- --------------------------------------------------------

--
-- Table structure for table `BCM_SUPPLIER`
--

DROP TABLE IF EXISTS `BCM_SUPPLIER`;
CREATE TABLE `BCM_SUPPLIER` (
  `SUPPLIER_REF` int(11) NOT NULL,
  `SUPPLIER_NAME` varchar(255) NOT NULL,
  `SUPP_CONTACT_NAME` varchar(255) DEFAULT NULL,
  `SUPP_ADDRESS` varchar(255) DEFAULT NULL,
  `SUPP_CONTACT_NUMBER` varchar(25) DEFAULT NULL,
  `SUPP_EMAIL` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BCM_SUPPLIER`
--

INSERT INTO `BCM_SUPPLIER` (`SUPPLIER_REF`, `SUPPLIER_NAME`, `SUPP_CONTACT_NAME`, `SUPP_ADDRESS`, `SUPP_CONTACT_NUMBER`, `SUPP_EMAIL`) VALUES
(1, 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 602801o', 'bparker@intnet.mu'),
(2, 'EMTELLO LTD', 'Megan Hembly', '998, Bistrop Street, Marlone, Pamplemousses, Mauritius', '2420641, 57841698.', 'mhem@my-t.mu'),
(3, 'FIRELAND BROS.', 'Amelia Bridney', '-, Main court bldg, Nerling road, Moka, Mauritius', '5948 0015', 'abridney@gmail.com'),
(4, 'FOXY ELECTRONICS', 'Reddy Floyd', 'C47, Green Street, -, Savanne, Mauritius', '5284 5412', 'foxyelec@yahoo.fr'),
(5, 'JINFIX COMPUTERS', 'Jordan Liu Min', '93, Bardeau lane, - , Port Louis, Mauritius', '58412556,2195412', 'contactus@jinfixcomputers.com'),
(6, 'LAMBONI STAT INC.', 'Frederic Pey', '9, Lamu Building, Stacy Street, Camp Hill, Pamplemousses', '52557435.', 'manustat@gmail.com'),
(7, 'MOTTOWAY CORP.', 'Stevens Seernah', 'B312, Cite la Cure, Jean XXIII Road, Port Louis, Mauritius', '5794 2513', 'steseer@mottoway.com'),
(8, 'PEGASUS LTD', 'Georges Neeroo', '40, Ferney Way, Mission Road, Curepipe, Mauritius', '461 5841, 5741254S', 'geonee@pegasus.mu'),
(9, 'SAFEDEST TAXI SERVICES', 'Steeve Narsimullu', '-, Le clezio street, Barbley wood, Highlands, Mauritius', '5874 1002, 217 4512', 'steeve.nar@safedest.mu'),
(10, 'STUFFIE STATIONERY', 'Zenhir Belall', '67, Bistro Route, Heneral Street, Vacaoas, Mauritius', '6547416', 'info@sstat.com');

-- --------------------------------------------------------

--
-- Table structure for table `XXBCM_ORDER_MGT`
--

DROP TABLE IF EXISTS `XXBCM_ORDER_MGT`;
CREATE TABLE `XXBCM_ORDER_MGT` (
  `ORDER_REF` varchar(2000) DEFAULT NULL,
  `ORDER_DATE` varchar(2000) DEFAULT NULL,
  `SUPPLIER_NAME` varchar(2000) DEFAULT NULL,
  `SUPP_CONTACT_NAME` varchar(2000) DEFAULT NULL,
  `SUPP_ADDRESS` varchar(2000) DEFAULT NULL,
  `SUPP_CONTACT_NUMBER` varchar(2000) DEFAULT NULL,
  `SUPP_EMAIL` varchar(2000) DEFAULT NULL,
  `ORDER_TOTAL_AMOUNT` varchar(2000) DEFAULT NULL,
  `ORDER_DESCRIPTION` varchar(2000) DEFAULT NULL,
  `ORDER_STATUS` varchar(2000) DEFAULT NULL,
  `ORDER_LINE_AMOUNT` varchar(2000) DEFAULT NULL,
  `INVOICE_REFERENCE` varchar(2000) DEFAULT NULL,
  `INVOICE_DATE` varchar(2000) DEFAULT NULL,
  `INVOICE_STATUS` varchar(2000) DEFAULT NULL,
  `INVOICE_HOLD_REASON` varchar(2000) DEFAULT NULL,
  `INVOICE_AMOUNT` varchar(2000) DEFAULT NULL,
  `INVOICE_DESCRIPTION` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `XXBCM_ORDER_MGT`
--

INSERT INTO `XXBCM_ORDER_MGT` (`ORDER_REF`, `ORDER_DATE`, `SUPPLIER_NAME`, `SUPP_CONTACT_NAME`, `SUPP_ADDRESS`, `SUPP_CONTACT_NUMBER`, `SUPP_EMAIL`, `ORDER_TOTAL_AMOUNT`, `ORDER_DESCRIPTION`, `ORDER_STATUS`, `ORDER_LINE_AMOUNT`, `INVOICE_REFERENCE`, `INVOICE_DATE`, `INVOICE_STATUS`, `INVOICE_HOLD_REASON`, `INVOICE_AMOUNT`, `INVOICE_DESCRIPTION`) VALUES
('PO001', '03-JAN-2017', 'PEGASUS LTD', 'Georges Neeroo', '40, Ferney Way, Mission Road, Curepipe, Mauritius', '461 5841, 5741254S', 'geonee@pegasus.mu', '10,000', 'Vehicle Spare parts', 'Closed', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('PO001-1', '03-JAN-2017', 'PEGASUS LTD', 'Georges Neeroo', '40, Ferney Way, Mission Road, Curepipe, Mauritius', '461 5841, 5741254S', 'geonee@pegasus.mu', NULL, 'Back lights', 'Received', '2,500', 'INV_PO001', '28-FEB-2017', 'Paid', NULL, '25oo', 'Part payment for vehicle spare parts'),
('PO001-2', '03-JAN-2017', 'PEGASUS LTD', 'Georges Neeroo', '40, Ferney Way, Mission Road, Curepipe, Mauritius', '461 5841, 5741254S', 'geonee@pegasus.mu', NULL, 'Spark plug', 'Received', '600', 'INV_PO001', '28-FEB-2017', 'Paid', NULL, '600', 'Part payment for vehicle spare parts'),
('PO002', '10-JAN-2017', 'MOTTOWAY CORP.', 'Stevens Seernah', 'B312, Cite la Cure, Jean XXIII Road, Port Louis, Mauritius', '5794 2513', 'steseer@mottoway.com', '750000', 'Purchase of Car', 'Open', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('PO002-1', '10-JAN-2017', 'MOTTOWAY CORP.', 'Stevens Seernah', 'B312, Cite la Cure, Jean XXIII Road, Port Louis, Mauritius', '5794 2513', 'steseer@mottoway.com', NULL, 'Purchase of Car Model X', 'Received', '10000o', 'INV_PO002.1', '01-MAR-2017', 'Paid', NULL, '100000', 'Part payment for purchase of car'),
('PO003', '24-JAN-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 602801o', 'bparker@intnet.mu', '57300', 'Computer screens', 'Closed', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('PO003-1', '24-JAN-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'Screens 22"', 'Received', '22000', 'INV_PO003.1', '22-MAR-2017', 'Paid', NULL, '22,000', 'Purchase of screens.'),
('PO003-2', '24-JAN-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 602801o', 'bparker@intnet.mu', NULL, 'Screens 35"', 'Received', '20300', 'INV_PO003.1', '22-MAR-2017', 'Paid', NULL, '20300', 'Purchase of screens.'),
('PO003-3', '24-JAN-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'Screens 15"', 'Received', 'S,000', 'INV_PO003.1', '22-MAR-2017', 'Paid', NULL, '5000', 'Purchase of screens.'),
('PO001-3', '03-JAN-2017', 'PEGASUS LTD', 'Georges Neeroo', '40, Ferney Way, Mission Road, Curepipe, Mauritius', '461 5841, 57412545', 'geonee@pegasus.mu', NULL, 'Fuel filter', 'Received', '2000', 'INV_PO001', '28-FEB-2017', 'Paid', NULL, '2,000', 'Part payment for vehicle spare parts'),
('PO004', '07-FEB-2017', 'LAMBONI STAT INC.', 'Frederic Pey', '9, Lamu Building, Stacy Street, Camp Hill, Pamplemousses', '52557435.', 'manustat@gmail.com', '6800', 'Purchase of Stationeries', 'Closed', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('PO004-1', '07-FEB-2017', 'LAMBONI STAT INC.', 'Frederic Pey', '9, Lamu Building, Stacy Street, Camp Hill, Pamplemousses', '52557435.', 'manustat@gmail.com', '2,000', 'Pen Parker blue', 'Received', '2000', 'INV_PO004', '15-FEB-2017', 'Paid', NULL, '2,000', 'Payment for pen'),
('PO004-2', '07-FEB-2017', 'LAMBONI STAT INC.', 'Frederic Pey', '9, Lamu Building, Stacy Street, Camp Hill, Pamplemousses', '52557435.', 'manustat@gmail.com', '2,000', 'Pencil HB boxes', 'Received', 'I200', 'INV_PO004', '15-FEB-2017', 'Paid', NULL, 'I200', 'Payment for pencil'),
('PO001-4', '03-JAN-2017', 'PEGASUS LTD', 'Georges Neeroo', '40, Ferney Way, Mission Road, Curepipe, Mauritius', '461 5841, 57412545', 'geonee@pegasus.mu', NULL, 'Air filter', 'Received', '800', 'INV_PO001', '28-FEB-2017', 'Paid', NULL, '800', 'Part payment for vehicle spare parts'),
('PO002-1', '10-JAN-2017', 'MOTTOWAY CORP.', 'Stevens Seernah', 'B312, Cite la Cure, Jean XXIII Road, Port Louis, Mauritius', '5794 2513', 'steseer@mottoway.com', NULL, 'Purchase of Car Model X', 'Received', '300,000', 'INV_PO002.2', '02-MAY-2017', 'Paid', NULL, '300,000', 'Part payment for purchase of car'),
('PO005', '07-APR-2017', 'EMTELLO LTD', 'Megan Hembly', '998, Bistrop Street, Marlone, Pamplemousses, Mauritius', '2420641, 57841698.', 'mhem@my-t.mu', '21000', 'International Magazines', 'Closed', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('PO005-1', '07-APR-2017', 'EMTELLO LTD', 'Megan Hembly', '998, Bistrop Street, Marlone, Pamplemousses, Mauritius', '2420641, 57841698.', 'mhem@my-t.mu', NULL, 'National geo nature', 'Received', '3,000', 'INV_PO005.1', '18-MAY-2017', 'Pending', 'Damaged magazine', '3,000', NULL),
('PO005-2', '07-APR-2017', 'EMTELLO LTD', 'Megan Hembly', '998, Bistrop Street, Marlone, Pamplemousses, Mauritius', '2420641, 57841698.', 'mhem@my-t.mu', NULL, 'Science world', 'Received', '5000', 'INV_PO005.1', '18-MAY-2017', 'Paid', NULL, '5000', NULL),
('PO003-4', '24-JAN-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'Screens 35"', 'Received', '10,000', 'INV_PO003.2', '15-MAY-2017', 'Paid', NULL, '10,000', 'Final payment for purchase of screens.'),
('PO002-1', '10-JAN-2017', 'MOTTOWAY CORP.', 'Stevens Seernah', 'B312, Cite la Cure, Jean XXIII Road, Port Louis, Mauritius', '5794 2513', 'steseer@mottoway.com', NULL, 'Purchase of Car Model X', 'Received', '249000', 'INV_PO002.3', '05-AUG-2017', 'Pending', NULL, '249000', 'Final payment for purchase of car'),
('PO004-3', '07-FEB-2017', 'LAMBONI STAT INC.', 'Frederic Pey', '9, Lamu Building, Stacy Street, Camp Hill, Pamplemousses', '52557435.', 'manustat@gmail.com', '3000', 'Paper reams', 'Received', '3,000', 'INV_PO004.1', '20-MAR-2017', 'Paid', NULL, '3000', 'Paper reams.'),
('PO004-4', '07-FEB-2017', 'LAMBONI STAT INC.', 'Frederic Pey', '9, Lamu Building, Stacy Street, Camp Hill, Pamplemousses', '52557435.', 'manustat@gmail.com', '600', 'Clips boxes', 'Cancelled', '600', NULL, NULL, NULL, NULL, NULL, NULL),
('PO005-3', '07-APR-2017', 'EMTELLO LTD', 'Megan Hembly', '998, Bistrop Street, Marlone, Pamplemousses, Mauritius', '2420641, 57841698.', 'mhem@my-t.mu', NULL, 'Science world', 'Received', '8000', 'INV_PO005.2', '22-JUN-2017', 'Paid', NULL, '8000', NULL),
('PO005-4', '07-APR-2017', 'EMTELLO LTD', 'Megan Hembly', '998, Bistrop Street, Marlone, Pamplemousses, Mauritius', '2420641, 57841698.', 'mhem@my-t.mu', NULL, 'Discovery mag', 'Received', '5000', 'INV_PO005.2', '22-JUN-2017', 'Paid', NULL, 'S000', NULL),
('PO001-5', '03-JAN-2017', 'PEGASUS LTD', 'Georges Neeroo', '40, Ferney Way, Mission Road, Curepipe, Mauritius', '461 5841, 57412545', 'geonee@pegasus.mu', NULL, 'Brake disc', 'Received', '3,000', 'INV_PO001.1', '04-APR-2017', 'Paid', NULL, '3000', 'Final payment for vehicle spare parts'),
('PO001-6', '03-JAN-2017', 'PEGASUS LTD', 'Georges Neeroo', '40, Ferney Way, Mission Road, Curepipe, Mauritius', '461 5841, 57412545', 'geonee@pegasus.mu', NULL, 'Axle', 'Received', '1100', 'INV_PO001.1', '04-APR-2017', 'Paid', NULL, '1100', 'Final payment for vehicle spare parts'),
('PO006', '16-FEB-2017', 'STUFFIE STATIONERY', 'Zenhir Belall', '67, Bistro Route, Heneral Street, Vacaoas, Mauritius', '6547416', 'info@sstat.com', '250000', 'Stationery orders', 'Open', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('PO006-1', '16-FEB-2017', 'STUFFIE STATIONERY', 'Zenhir Belall', '67, Bistro Route, Heneral Street, Vacaoas, Mauritius', '6547416', 'info@sstat.com', NULL, 'Packet 1', 'Received', '24300', 'INV_PO006.1', '22-MAR-2017', 'Paid', NULL, '24300', 'First delivery'),
('PO007', '03-06-2017', 'SAFEDEST TAXI SERVICES', 'Steeve Narsimullu', '-, Le clezio street, Barbley wood, Highlands, Mauritius', '5874 1002, 217 4512', 'steeve.nar@safedest.mu', '26700', 'Taxi services fees', 'Closed', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('PO008', '05-JUN-2017', 'JINFIX COMPUTERS', 'Jordan Liu Min', '93, Bardeau lane, - , Port Louis, Mauritius', '58412556,2195412', 'contactus@jinfixcomputers.com', '85200', 'Orders of computer spare parts', 'Open', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('PO008-1', '05-JUN-2017', 'JINFIX COMPUTERS', 'Jordan Liu Min', '93, Bardeau lane, - , Port Louis, Mauritius', '58412556,2195412', 'contactus@jinfixcomputers.com', NULL, '10 HDDs 3TB', 'Received', '3025o', 'INV_PO008.1', '02-AUG-2017', 'Paid', NULL, '15250', 'Computer oders invoice - 1'),
('PO008-2', '05-JUN-2017', 'JINFIX COMPUTERS', 'Jordan Liu Min', '93, Bardeau lane, - , Port Louis, Mauritius', '58412556,2195412', 'contactus@jinfixcomputers.com', NULL, '10 Motherboard Asus PRIME Z270-A', 'Received', '48000', 'INV_PO008.1', '02-AUG-2017', 'Paid', NULL, '25000', 'Computer oders invoice - 1'),
('PO009', '18-JUN-2017', 'FIRELAND BROS.', 'Amelia Bridney', '-, Main court bldg, Nerling road, Moka, Mauritius', '5948 0015', 'abridney@gmail.com', '36800', 'Security vests', 'Open', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('PO009-1', '18-JUN-2017', 'FIRELAND BROS.', 'Amelia Bridney', '-, Main court bldg, Nerling road, Moka, Mauritius', '5948 0015', 'abridney@gmail.com', NULL, 'Security vests for firewardens', 'Received', '22500', 'INV_PO009.1', '24-AUG-2017', 'Paid', NULL, '22,500', 'Security vests'),
('PO010', '03-JUL-2017', 'FOXY ELECTRONICS', 'Reddy Floyd', 'C47, Green Street, -, Savanne, Mauritius', '5284 5412', 'foxyelec@yahoo.fr', '182,700', 'Electronic spare parts', 'Closed', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('PO010-1', '03-JUL-2017', 'FOXY ELECTRONICS', 'Reddy Floyd', 'C47, Green Street, -, Savanne, Mauritius', '5284 5412', 'foxyelec@yahoo.fr', NULL, 'Electronic Component Lead 2000 Kgs', 'Received', '98000', 'INV_PO010.1', '15-AUG-2017', 'Paid', NULL, '98,000', 'Electronic spare parts - Inv 1'),
('PO010-1', '03-JUL-2017', 'FOXY ELECTRONICS', 'Reddy Floyd', 'C47, Green Street, -, Savanne, Mauritius', '5284 5412', 'foxyelec@yahoo.fr', NULL, 'Air Conditioner Fan Capacitor x 1000', 'Received', '17500', 'INV_PO010.1', '15-AUG-2017', 'Paid', NULL, '17,500', 'Electronic spare parts - Inv 1'),
('PO010-2', '03-JUL-2017', 'FOXY ELECTRONICS', 'Reddy Floyd', 'C47, Green Street, -, Savanne, Mauritius', '5284 5412', 'foxyelec@yahoo.fr', NULL, 'Aluminium LED PCB Assemblies x 100', 'Received', '28,000', 'INV_PO010.1', '02-SEP-2017', 'Paid', NULL, '28000', 'Electronic spare parts - Inv 2'),
('PO010-2', '03-JUL-2017', 'FOXY ELECTRONICS', 'Reddy Floyd', 'C47, Green Street, -, Savanne, Mauritius', '5284 5412', 'foxyelec@yahoo.fr', NULL, 'Starter capacitor x 2000', 'Received', '18200', 'INV_PO010.1', '02-09-2017', 'Paid', NULL, '18200', 'Electronic spare parts - Inv 2'),
('PO010-3', '03-07-2017', 'FOXY ELECTRONICS', 'Reddy Floyd', 'C47, Green Street, -, Savanne, Mauritius', '5284 5412', 'foxyelec@yahoo.fr', NULL, 'Block connector universal x 200', 'Received', '2I,000', 'INV_PO010.1', '15-AUG-2017', 'Paid', NULL, '21000', 'Electronic spare parts - Inv 1'),
('PO011', '06-07-2017', 'LAMBONI STAT INC.', 'Frederic Pey', '9, Lamu Building, Stacy Street, Camp Hill, Pamplemousses', '52557435.', 'manustat@gmail.com', '43200', 'Purchase of Stationeries', 'Closed', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('PO011-1', '06-JUL-2017', 'LAMBONI STAT INC.', 'Frederic Pey', '9, Lamu Building, Stacy Street, Camp Hill, Pamplemousses', '52557435.', 'manustat@gmail.com', NULL, 'Staplers Heavy duty x 10', 'Received', '3200', 'INV_PO011.1', '18-SEP-2017', 'Paid', NULL, '3,200', 'Stationeries'),
('PO008-1', '05-JUN-2017', 'JINFIX COMPUTERS', 'Jordan Liu Min', '93, Bardeau lane, - , Port Louis, Mauritius', '58412556,2195412', 'contactus@jinfixcomputers.com', NULL, '10 HDDs 3TB', 'Received', '30250', 'INV_PO008.2', '28-08-2017', 'Paid', NULL, '15,000', 'Computer oders invoice - 2'),
('PO008-2', '05-JUN-2017', 'JINFIX COMPUTERS', 'Jordan Liu Min', '93, Bardeau lane, - , Port Louis, Mauritius', '58412556,2195412', 'contactus@jinfixcomputers.com', NULL, '10 Motherboard Asus PRIME Z270-A', 'Received', '48000', 'INV_PO008.2', '28-AUG-2017', 'Paid', NULL, '23000', 'Computer oders invoice - 2'),
('PO006-1', '16-FEB-2017', 'STUFFIE STATIONERY', 'Zenhir Belall', '67, Bistro Route, Heneral Street, Vacaoas, Mauritius', '6547416', 'info@sstat.com', NULL, 'Packet 3', 'Received', '25,400', 'INV_PO006.3', '21-MAY-2017', 'Paid', NULL, '25,400', 'Third delivery'),
('PO011-2', '06-JUL-2017', 'LAMBONI STAT INC.', 'Frederic Pey', '9, Lamu Building, Stacy Street, Camp Hill, Pamplemousses', '52557435.', 'manustat@gmail.com', NULL, 'Organizers x 200', 'Received', '40000', 'INV_PO011.1', '18-SEP-2017', 'Paid', NULL, '40000', 'Stationeries'),
('PO012', '16-AUG-2017', 'PEGASUS LTD', 'Georges Neeroo', '40, Ferney Way, Mission Road, Curepipe, Mauritius', '461 5841, 57412545', 'geonee@pegasus.mu', '265000', 'Vehicle Spare parts', 'Open', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('PO012-1', '16-AUG-2017', 'PEGASUS LTD', 'Georges Neeroo', '40, Ferney Way, Mission Road, Curepipe, Mauritius', '461 5841, 57412545', 'geonee@pegasus.mu', NULL, 'Aluminium evaporator x 15', 'Received', '3,4S0', 'INV_PO012.1', '07-AUG-2017', 'Paid', NULL, '3,450', 'Vehicle spare parts - Part Pay 1'),
('PO006-1', '16-FEB-2017', 'STUFFIE STATIONERY', 'Zenhir Belall', '67, Bistro Route, Heneral Street, Vacaoas, Mauritius', '6547416', 'info@sstat.com', NULL, 'Packet 4', 'Received', '50200', 'INV_PO006.4', '17-06-2017', 'Paid', NULL, '50200', 'Fourth delivery'),
('PO008-2', '05-JUN-2017', 'JINFIX COMPUTERS', 'Jordan Liu Min', '93, Bardeau lane, - , Port Louis, Mauritius', '58412556,2195412', 'contactus@jinfixcomputers.com', NULL, 'Seagate Barracuda 2TB SATA Hard Drive', 'Received', '6,950', 'INV_PO008.2', '28-AUG-2017', 'Paid', NULL, '6,950', 'Vehicle spare parts - Part Pay 2'),
('PO012-1', '16-AUG-2017', 'PEGASUS LTD', 'Georges Neeroo', '40, Ferney Way, Mission Road, Curepipe, Mauritius', '461 5841, 57412545', 'geonee@pegasus.mu', NULL, 'Wheels and balancing', 'Received', '40000', 'INV_PO012.2', '04-09-2017', 'Paid', NULL, '40000', 'Vehicle spare parts - Part Pay 2'),
('PO012-2', '16-AUG-2017', 'PEGASUS LTD', 'Georges Neeroo', '40, Ferney Way, Mission Road, Curepipe, Mauritius', '461 5841, 57412545', 'geonee@pegasus.mu', NULL, 'Servicing of cars', 'Received', '37800', 'INV_PO012.1', '07-AUG-2017', 'Paid', NULL, '37800', 'Vehicle spare parts - Part Pay 1'),
('PO012-2', '16-AUG-2017', 'PEGASUS LTD', 'Georges Neeroo', '40, Ferney Way, Mission Road, Curepipe, Mauritius', '461 5841, 57412545', 'geonee@pegasus.mu', NULL, 'Dashboard for cards', 'Received', '12,500', 'INV_PO012.2', '04-SEP-2017', 'Paid', NULL, '12,500', 'Vehicle spare parts - Part Pay 2'),
('PO012-2', '16-AUG-2017', 'PEGASUS LTD', 'Georges Neeroo', '40, Ferney Way, Mission Road, Curepipe, Mauritius', '461 5841, 57412545', 'geonee@pegasus.mu', NULL, 'Rear door + repair', 'Received', '28000', 'INV_PO012.3', '29-SEP-2017', 'Paid', NULL, '28000', 'Vehicle spare parts - Part Pay 3'),
('PO012-3', '16-AUG-2017', 'PEGASUS LTD', 'Georges Neeroo', '40, Ferney Way, Mission Road, Curepipe, Mauritius', '461 5841, 57412545', 'geonee@pegasus.mu', NULL, 'High pressure fuel injector nozzle OEM x 10', 'Received', '7250', 'INV_PO012.1', '07-AUG-2017', 'Paid', NULL, '7250', 'Vehicle spare parts - Part Pay 1'),
('PO012-4', '16-AUG-2017', 'PEGASUS LTD', 'Georges Neeroo', '40, Ferney Way, Mission Road, Curepipe, Mauritius', '461 5841, 57412545', 'geonee@pegasus.mu', NULL, 'Air suspension compressor x 3', 'Received', '55,870', 'INV_PO012.2', '04-SEP-2017', 'Paid', NULL, '55,870', 'Vehicle spare parts - Part Pay 2'),
('PO012-5', '16-AUG-2017', 'PEGASUS LTD', 'Georges Neeroo', '40, Ferney Way, Mission Road, Curepipe, Mauritius', '461 5841, 57412545', 'geonee@pegasus.mu', NULL, 'Aluminium alloy set x 5', 'Received', '43750', 'INV_PO012.3', '29-SEP-2017', 'Paid', NULL, '43750', 'Vehicle spare parts - Part Pay 3'),
('PO012-5', '16-AUG-2017', 'PEGASUS LTD', 'Georges Neeroo', '40, Ferney Way, Mission Road, Curepipe, Mauritius', '461 5841, 57412545', 'geonee@pegasus.mu', NULL, 'Master brake x 12', 'Received', '12600', 'INV_PO012.3', '29-SEP-2017', 'Paid', NULL, '12600', 'Vehicle spare parts - Part Pay 3'),
('PO006-1', '16-02-2017', 'STUFFIE STATIONERY', 'Zenhir Belall', '67, Bistro Route, Heneral Street, Vacaoas, Mauritius', '6547416', 'info@sstat.com', NULL, 'Packet 5', 'Received', '70800', 'INV_PO006.5', '27-JUL-2017', 'Paid', NULL, '70800', 'Fifth delivery'),
('PO013', '20-AUG-2017', 'MOTTOWAY CORP.', 'Stevens Seernah', 'B312, Cite la Cure, Jean XXIII Road, Port Louis, Mauritius', '5794 2513', 'steseer@mottoway.com', '581,9625', 'Purchase of Cars', 'Closed', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('PO013-1', '20-08-2017', 'MOTTOWAY CORP.', 'Stevens Seernah', 'B312, Cite la Cure, Jean XXIII Road, Port Louis, Mauritius', '5794 2513', 'steseer@mottoway.com', NULL, 'Audi Q5', 'Received', '145,2500', 'INV_PO013.1', '28-SEP-2017', 'Paid', NULL, '145,2500', 'Car purchase'),
('PO013-2', '20-AUG-2017', 'MOTTOWAY CORP.', 'Stevens Seernah', 'B312, Cite la Cure, Jean XXIII Road, Port Louis, Mauritius', '5794 2513', 'steseer@mottoway.com', NULL, 'Audi Q7', 'Received', '1974000', 'INV_PO013.1', '28-09-2017', 'Paid', NULL, '1974000', 'Car purchase'),
('PO013-3', '20-AUG-2017', 'MOTTOWAY CORP.', 'Stevens Seernah', 'B312, Cite la Cure, Jean XXIII Road, Port Louis, Mauritius', '5794 2513', 'steseer@mottoway.com', NULL, 'Chevrolet Equinox', 'Received', '130,2000', 'INV_PO013.1', '28-SEP-2017', 'Paid', NULL, '130,2000', 'Car purchase'),
('PO013-4', '20-AUG-2017', 'MOTTOWAY CORP.', 'Stevens Seernah', 'B312, Cite la Cure, Jean XXIII Road, Port Louis, Mauritius', '5794 2513', 'steseer@mottoway.com', NULL, 'Hyundai Tucson', 'Received', '1091125', 'INV_PO013.1', '28-SEP-2017', 'Paid', NULL, '1091125', 'Car purchase'),
('PO006-1', '16-FEB-2017', 'STUFFIE STATIONERY', 'Zenhir Belall', '67, Bistro Route, Heneral Street, Vacaoas, Mauritius', '6547416', 'info@sstat.com', NULL, 'Packet 6', 'Received', '60,000', 'INV_PO006.6', '16-08-2017', 'Paid', NULL, '60,000', 'Sixth delivery'),
('PO007-1', '03-JUN-2017', 'SAFEDEST TAXI SERVICES', 'Steeve Narsimullu', '-, Le clezio street, Barbley wood, Highlands, Mauritius', '5874 1002, 2I7 4512', 'steeve.nar@safedest.mu', NULL, 'Employee journey taxi service', 'Received', '4,500', 'INV_PO007.1', '30-JUL-2017', 'Paid', NULL, '4500', 'Trip for Saunders'),
('PO007-2', '03-JUN-2017', 'SAFEDEST TAXI SERVICES', 'Steeve Narsimullu', '-, Le clezio street, Barbley wood, Highlands, Mauritius', '5874 1002, 2I7 4512', 'steeve.nar@safedest.mu', NULL, 'Employee journey taxi service', 'Received', '4200', 'INV_PO007.1', '30-JUL-2017', 'Paid', NULL, '4200', 'Trip for Mike'),
('PO007-3', '03-JUN-2017', 'SAFEDEST TAXI SERVICES', 'Steeve Narsimullu', '-, Le clezio street, Barbley wood, Highlands, Mauritius', '5874 1002, 2I7 4512', 'steeve.nar@safedest.mu', NULL, 'Employee journey taxi service', 'Cancelled', '5200', NULL, NULL, NULL, NULL, NULL, NULL),
('PO007-4', '03-JUN-2017', 'SAFEDEST TAXI SERVICES', 'Steeve Narsimullu', '-, Le clezio street, Barbley wood, Highlands, Mauritius', '5874 1002, 2I7 4512', 'steeve.nar@safedest.mu', NULL, 'Employee journey taxi service', 'Received', '4,800', 'INV_PO007.1', '30-JUL-2017', 'Paid', NULL, '4800', 'Trip for Shobnee'),
('PO007-5', '03-JUN-2017', 'SAFEDEST TAXI SERVICES', 'Steeve Narsimullu', '-, Le clezio street, Barbley wood, Highlands, Mauritius', '5874 1002, 2I7 4512', 'steeve.nar@safedest.mu', NULL, 'Employee journey taxi service', 'Received', '3700', 'INV_PO007.1', '30-07-2017', 'Paid', NULL, '3700', 'Trip for Mikaen'),
('PO006-1', '16-FEB-2017', 'STUFFIE STATIONERY', 'Zenhir Belall', '67, Bistro Route, Heneral Street, Vacaoas, Mauritius', '6547416', 'info@sstat.com', NULL, 'Packet 2', 'Received', '4300', 'INV_PO006.2', '18-04-2017', 'Paid', NULL, '4300', 'Second delivery'),
('PO014', '15-SEP-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', '400,120', 'Purchases of Digital equipment', 'Open', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('PO014-1', '15-SEP-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, '2.5 EXTERNAL TOSHIBA 1TB HARD DISK USB 3.0 x 2', 'Received', '5,600', 'INV_PO014.1', '03-OCT-2017', 'Paid', NULL, '5,600', 'Invoice payment SN#001'),
('PO014-2', '15-09-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, '2.5 EXTERNAL TOSHIBA 2TB HARD DISK USB 3.0 x 3', 'Received', '13250', 'INV_PO014.2', '15-OCT-2017', 'Paid', NULL, '13250', 'Invoice payment SN#002'),
('PO014-3', '15-SEP-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'NOTEBOOK SATA HDD - 500 GB x 5', 'Received', '10,000', 'INV_PO014.2', '15-OCT-2017', 'Paid', NULL, '10,000', 'Invoice payment SN#002'),
('PO014-4', '15-SEP-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, '3TB SATA HARD DISK x 4', 'Received', '15900', 'INV_PO014.3', '27-10-2017', 'Paid', NULL, '15900', 'Invoice payment SN#003'),
('PO014-5', '15-SEP-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'WESTERN DIGITAL USB 3.0 EXTERNAL HARD DISK 3.5 4TB x 2', 'Received', '13850', 'INV_PO014.4', '05-NOV-2017', 'Pending', '1 faulty HD to return before payment', '13850', 'Invoice payment SN#004'),
('PO014-1', '15-SEP-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'FAN UNIT x 20', 'Cancelled', '800', NULL, NULL, NULL, NULL, NULL, NULL),
('PO014-1', '15-SEP-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'EPSON EB-S31 3LCD PROJECTOR x 3', 'Received', '54,850', 'INV_PO014.3', '27-OCT-2017', 'Paid', NULL, '54,850', 'Invoice payment SN#003'),
('PO014-2', '15-09-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'VIEWSONIC PJD5155 PROJECTOR', 'Received', '17300', 'INV_PO014.1', '03-OCT-2017', 'Paid', NULL, '17300', 'Invoice payment SN#001'),
('PO014-2', '15-SEP-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'COOLER MASTER SEIDON120V V3 PLUS WATER-COOLING KIT x 5', 'Received', '13500', 'INV_PO014.1', '03-OCT-2017', 'Paid', NULL, '13500', 'Invoice payment SN#001'),
('PO014-3', '15-SEP-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'GENIUS MEDIA POINTER 900BT x 3', 'Received', '4275', 'INV_PO014.1', '03-OCT-2017', 'Paid', NULL, '4275', 'Invoice payment SN#001'),
('PO014-3', '15-SEP-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'USB WIRELESS <<T>> LASER POINTER PRESENTER x 2', 'Received', '900', 'INV_PO014.3', '27-OCT-2017', 'Pending', 'Pointers not compatible with system', '900', 'Invoice payment SN#003'),
('PO014-3', '15-SEP-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'ASUS H110M-A (INTEL H110) DDR4 LGA1151 MATX x 4', 'Received', '17,600', 'INV_PO014.4', '05-NOV-2017', 'Paid', NULL, '17,600', 'Invoice payment SN#004'),
('PO014-3', '15-SEP-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'ASUS B150M-K DDR4 (INTEL B150) LGA1151 MATX x 2', 'Received', '11900', 'INV_PO014.4', '05-11-2017', 'Paid', NULL, '11900', 'Invoice payment SN#004'),
('PO014-4', '15-SEP-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'ASUS H81M-A (INTEL H81) LGA1150 MATX x 2', 'Received', '7920', 'INV_PO014.1', '03-OCT-2017', 'Paid', NULL, '7920', 'Invoice payment SN#001'),
('PO014-4', '15-SEP-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'HP ADVANTAGE 4535 ALL-IN-ONE INKJET PRINTER', 'Received', '3550', 'INV_PO014.2', '15-OCT-2017', 'Pending', NULL, '3550', 'Invoice payment SN#002'),
('PO014-4', '15-SEP-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'HP M277DW WIFI COLOUR LASERJET PRO MFP', 'Received', '15,200', 'INV_PO014.1', '03-OCT-2017', 'Paid', NULL, '15,200', 'Invoice payment SN#001'),
('PO014-5', '15-SEP-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'HP OFFICEJET PRO 6830 E-ALL-IN-ONE PRINTER', 'Received', '5300', 'INV_PO014.3', '27-OCT-2017', 'Paid', NULL, '5300', 'Invoice payment SN#003'),
('PO014-5', '15-SEP-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'EPSON LQ310 DOT MATRIX PRINTER', 'Received', '12125', 'INV_PO014.3', '27-OCT-2017', 'Paid', NULL, '12125', 'Invoice payment SN#003'),
('PO014-5', '15-SEP-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'LENOVO B50-30 x 5', 'Received', '72500', 'INV_PO014.1', '03-OCT-2017', 'Pending', NULL, '72500', 'Invoice payment SN#001'),
('PO014-5', '15-09-2017', 'DIGISAY CO. LTD.', 'Berry Parker', '68, Marock Lane, - , Vacoas, Mauritius', '57841266, 6028010', 'bparker@intnet.mu', NULL, 'DELL N3543 CORE i5 x 3', 'Cancelled', '103,800', NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `BCM_INVOICE`
--
ALTER TABLE `BCM_INVOICE`
  ADD PRIMARY KEY (`INVOICE_REFERENCE`),
  ADD KEY `FK_BCM_INVOICE` (`SUPPLIER_REF`);

--
-- Indexes for table `BCM_ORDER`
--
ALTER TABLE `BCM_ORDER`
  ADD PRIMARY KEY (`ORDER_REF`);

--
-- Indexes for table `BCM_ORDER_LINE`
--
ALTER TABLE `BCM_ORDER_LINE`
  ADD PRIMARY KEY (`ORDER_LINE_ID`),
  ADD KEY `FK_BCM_ORDER_LINE` (`ORDER_REF`);

--
-- Indexes for table `BCM_SUPPLIER`
--
ALTER TABLE `BCM_SUPPLIER`
  ADD PRIMARY KEY (`SUPPLIER_REF`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `BCM_ORDER_LINE`
--
ALTER TABLE `BCM_ORDER_LINE`
  MODIFY `ORDER_LINE_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;
--
-- AUTO_INCREMENT for table `BCM_SUPPLIER`
--
ALTER TABLE `BCM_SUPPLIER`
  MODIFY `SUPPLIER_REF` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `BCM_INVOICE`
--
ALTER TABLE `BCM_INVOICE`
  ADD CONSTRAINT `FK_BCM_INVOICE` FOREIGN KEY (`SUPPLIER_REF`) REFERENCES `BCM_SUPPLIER` (`SUPPLIER_REF`);

--
-- Constraints for table `BCM_ORDER_LINE`
--
ALTER TABLE `BCM_ORDER_LINE`
  ADD CONSTRAINT `FK_BCM_ORDER_LINE` FOREIGN KEY (`ORDER_REF`) REFERENCES `BCM_ORDER` (`ORDER_REF`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
